export interface User {
  id: number;
  name: string;
  phone: string;
  latitude: number | null;
  longitude: number | null;
  panic_status: 'active' | 'inactive' | 'resolved';
  created_at: string;
}

export interface PanicAlert {
  id: number;
  user_name: string;
  user_phone: string;
  latitude: number | null;
  longitude: number | null;
  status: string;
  created_at: string;
}

export interface EventLog {
  id: number;
  type: string;
  user_name: string;
  description: string;
  created_at: string;
}
