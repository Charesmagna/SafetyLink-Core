import React from 'react';
import { Shield, Bluetooth, MapPin, WifiOff, ArrowRight, Github } from 'lucide-react';

interface LandingPageProps {
  onNavigate: (view: 'dashboard') => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-[#05070a] flex flex-col font-sans text-slate-300 selection:bg-cyan-500/30">
      <header className="w-full bg-[#0a0c12] border-b border-slate-800 px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-cyan-500 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.5)]">
            <Shield className="w-5 h-5 text-black" />
          </div>
          <span className="text-xl font-bold tracking-tight text-white">SafetyLink Core</span>
        </div>
        <nav className="flex items-center gap-4">
          <a
            href="https://github.com/Charesmagna/SafetyLink-Core"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-slate-400 hover:text-cyan-400 transition-colors text-sm font-medium"
          >
            <Github className="w-5 h-5" />
            GitHub
          </a>
          <button
            onClick={() => onNavigate('dashboard')}
            className="bg-cyan-500 hover:bg-cyan-400 text-black px-4 py-2 rounded-full font-bold text-sm transition-colors shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center gap-2"
          >
            Open Dashboard
            <ArrowRight className="w-4 h-4" />
          </button>
        </nav>
      </header>

      <main className="flex-1">
        <section className="w-full max-w-7xl mx-auto px-6 py-24 flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 space-y-6">
            <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight text-white leading-tight">
              Personal safety, <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600">
                reimagined.
              </span>
            </h1>
            <p className="text-lg text-slate-400 max-w-xl leading-relaxed">
              An advanced open-source personal safety network providing offline capabilities, BLE device integrations, and real-time location services when you need them most.
            </p>
            <div className="flex items-center gap-4 pt-4">
              <button
                onClick={() => onNavigate('dashboard')}
                className="bg-cyan-500 hover:bg-cyan-400 text-black px-6 py-3 rounded-full font-bold transition-colors shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center gap-2"
              >
                Access Dashboard
              </button>
              <a
                href="https://safetylink.online"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#0a0c12] border border-slate-700 hover:border-slate-500 text-slate-300 px-6 py-3 rounded-full font-medium transition-colors"
              >
                Learn More
              </a>
            </div>
          </div>
          <div className="flex-1 w-full relative">
            <div className="aspect-square max-w-md mx-auto relative">
              <div className="absolute inset-0 bg-cyan-500/10 rounded-full blur-3xl opacity-50"></div>
              <div className="relative bg-[#0a0c12] border border-slate-800 rounded-2xl shadow-xl overflow-hidden h-full p-8 flex flex-col justify-center items-center gap-6">
                <div className="w-32 h-32 bg-cyan-500/10 border border-cyan-500/20 rounded-full flex items-center justify-center animate-pulse">
                   <Shield className="w-16 h-16 text-cyan-500" />
                </div>
                <div className="text-center space-y-2">
                   <h3 className="text-xl font-bold text-white">System Active</h3>
                   <p className="text-sm text-slate-400">Monitoring secure connections across 3 devices.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-[#05070a] border-t border-slate-800 py-24 w-full">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold tracking-tight text-white mb-4">Core Capabilities</h2>
              <p className="text-slate-400 max-w-2xl mx-auto">Engineered for reliability in critical situations, utilizing modern Android capabilities and cross-platform architecture.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-[#0a0c12] border border-slate-800 rounded-2xl p-8 hover:border-slate-700 transition-colors">
                <div className="w-12 h-12 bg-cyan-500/10 border border-cyan-500/20 text-cyan-500 rounded-xl flex items-center justify-center mb-6 shadow-[0_0_15px_rgba(6,182,212,0.2)]">
                  <Bluetooth className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">BLE Integration</h3>
                <p className="text-slate-400 leading-relaxed">
                  Seamlessly connect with Bluetooth Low Energy panic buttons and smartwatches for instant, discreet alerts.
                </p>
              </div>

              <div className="bg-[#0a0c12] border border-slate-800 rounded-2xl p-8 hover:border-slate-700 transition-colors">
                <div className="w-12 h-12 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-xl flex items-center justify-center mb-6 shadow-[0_0_15px_rgba(59,130,246,0.2)]">
                  <MapPin className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">Location Services</h3>
                <p className="text-slate-400 leading-relaxed">
                  High-accuracy, battery-optimized background location tracking ensuring responders know exactly where you are.
                </p>
              </div>

              <div className="bg-[#0a0c12] border border-slate-800 rounded-2xl p-8 hover:border-slate-700 transition-colors">
                <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl flex items-center justify-center mb-6 shadow-[0_0_15px_rgba(16,185,129,0.2)]">
                  <WifiOff className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">Offline Resilience</h3>
                <p className="text-slate-400 leading-relaxed">
                  Local-first architecture ensures critical data and pending alerts are stored securely and synced when connectivity returns.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#0a0c12] text-slate-500 py-8 px-6 text-center text-sm border-t border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} SafetyLink Core. Open Source Initiative.</p>
          <div className="flex gap-4">
            <a href="https://safetylink.online" className="hover:text-cyan-400 transition-colors">safetylink.online</a>
            <a href="https://github.com/Charesmagna/SafetyLink-Core" className="hover:text-cyan-400 transition-colors">GitHub Repository</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
