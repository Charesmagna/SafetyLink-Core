import React, { useState } from 'react';
import { 
  Shield, 
  ShieldAlert, 
  Bell, 
  Settings, 
  LogOut, 
  Watch, 
  Smartphone, 
  MapPin, 
  Activity,
  CheckCircle2,
  AlertTriangle,
  BatteryCharging
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const mockActivityData = [
  { time: '08:00', connections: 2 },
  { time: '10:00', connections: 3 },
  { time: '12:00', connections: 3 },
  { time: '14:00', connections: 1 },
  { time: '16:00', connections: 2 },
  { time: '18:00', connections: 3 },
  { time: '20:00', connections: 3 },
];

const mockDevices = [
  { id: 'dev-1', name: 'Galaxy Watch 6', type: 'watch', status: 'connected', battery: 84 },
  { id: 'dev-2', name: 'Safety Button (Keyring)', type: 'button', status: 'connected', battery: 92 },
  { id: 'dev-3', name: 'Secondary Phone', type: 'phone', status: 'disconnected', battery: 0 },
];

const mockAlerts = [
  { id: 'al-1', type: 'info', message: 'Galaxy Watch 6 connected successfully.', time: '10 mins ago' },
  { id: 'al-2', type: 'warning', message: 'Secondary Phone lost connection.', time: '2 hours ago' },
  { id: 'al-3', type: 'info', message: 'Location services synced.', time: '3 hours ago' },
];

interface DashboardProps {
  onNavigate: (view: 'landing') => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const [systemStatus, setSystemStatus] = useState<'safe' | 'alert'>('safe');

  return (
    <div className="min-h-screen bg-[#05070a] flex flex-col md:flex-row font-sans text-slate-300 selection:bg-cyan-500/30">
      
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-[#0a0c12] border-r border-slate-800 flex flex-col hidden md:flex sticky top-0 h-screen">
        <div className="p-6 border-b border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 bg-cyan-500 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.5)]">
            <Shield className="w-5 h-5 text-black" />
          </div>
          <span className="text-lg font-bold tracking-tight text-white">SafetyLink</span>
        </div>
        <nav className="flex-1 px-4 py-4 space-y-1">
          <button className="w-full flex items-center gap-3 px-4 py-3 bg-cyan-500/10 border-l-2 border-cyan-500 text-cyan-400 rounded-r-lg font-medium transition-colors group">
            <Activity className="w-5 h-5" />
            Overview
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-white rounded-lg font-medium transition-colors group">
            <Watch className="w-5 h-5 group-hover:text-white" />
            Devices
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-white rounded-lg font-medium transition-colors group">
            <MapPin className="w-5 h-5 group-hover:text-white" />
            Location
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-white rounded-lg font-medium transition-colors group">
            <Settings className="w-5 h-5 group-hover:text-white" />
            Settings
          </button>
        </nav>
        <div className="p-4 border-t border-slate-800">
          <button 
            onClick={() => onNavigate('landing')}
            className="w-full flex items-center gap-3 px-3 py-2 text-slate-500 hover:text-white transition-colors font-medium"
          >
            <LogOut className="w-5 h-5" />
            Exit Dashboard
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-h-screen">
        {/* Topbar (Mobile) & Header */}
        <header className="bg-[#0a0c12] border-b border-slate-800 px-6 py-4 flex items-center justify-between md:justify-end sticky top-0 z-10">
          <div className="flex md:hidden items-center gap-2">
            <div className="w-6 h-6 bg-cyan-500 rounded flex items-center justify-center">
               <Shield className="w-4 h-4 text-black" />
            </div>
            <span className="text-lg font-bold tracking-tight text-white">SafetyLink</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="text-slate-400 hover:text-cyan-400 transition-colors relative">
              <Bell className="w-6 h-6" />
              <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-cyan-500 border-2 border-[#0a0c12] rounded-full shadow-[0_0_8px_#06b6d4]"></span>
            </button>
            <div className="w-9 h-9 rounded-full bg-cyan-500/10 flex items-center justify-center border border-cyan-500/30">
              <span className="text-sm font-bold text-cyan-400">JD</span>
            </div>
          </div>
        </header>

        <div className="p-6 md:p-8 max-w-6xl mx-auto w-full flex-1 space-y-8">
          
          {/* Header & Main Status */}
          <div className="flex flex-col md:flex-row gap-6 justify-between items-start md:items-center">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-white">Dashboard Overview</h1>
              <p className="text-slate-400 mt-1">Monitor your connected devices and safety status.</p>
            </div>
            
            <button 
              onClick={() => setSystemStatus(prev => prev === 'safe' ? 'alert' : 'safe')}
              className={`flex items-center gap-2 px-6 py-3 rounded-full font-bold shadow-sm transition-all border ${
                systemStatus === 'safe' 
                  ? 'bg-slate-900 border-slate-700 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.1)] hover:border-cyan-500/50' 
                  : 'bg-red-900/50 border-red-500 text-red-400 shadow-[0_0_15px_rgba(239,68,68,0.3)] hover:bg-red-900/70 animate-pulse'
              }`}
            >
              {systemStatus === 'safe' ? (
                <>
                  <CheckCircle2 className="w-5 h-5" />
                  Status: Secure
                </>
              ) : (
                <>
                  <ShieldAlert className="w-5 h-5" />
                  SOS ACTIVE
                </>
              )}
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Left Column: Devices & Alerts */}
            <div className="lg:col-span-1 space-y-8">
              
              {/* Devices Panel */}
              <div className="bg-[#0a0c12] rounded-2xl border border-slate-800 shadow-sm overflow-hidden">
                <div className="p-5 border-b border-slate-800 flex justify-between items-center">
                  <h2 className="font-semibold text-white">Connected Devices</h2>
                  <button className="text-cyan-400 text-sm font-medium hover:underline">Add New</button>
                </div>
                <div className="divide-y divide-slate-800 p-2">
                  {mockDevices.map(device => (
                    <div key={device.id} className="p-3 flex items-center justify-between hover:bg-slate-800/50 rounded-lg transition-colors">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg border ${device.status === 'connected' ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20' : 'bg-slate-800 text-slate-500 border-transparent'}`}>
                          {device.type === 'watch' ? <Watch className="w-5 h-5" /> : 
                           device.type === 'phone' ? <Smartphone className="w-5 h-5" /> : 
                           <Activity className="w-5 h-5" />}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-200">{device.name}</p>
                          <p className={`text-xs capitalize ${device.status === 'connected' ? 'text-cyan-500' : 'text-slate-500'}`}>
                            {device.status}
                          </p>
                        </div>
                      </div>
                      {device.status === 'connected' && (
                        <div className="flex items-center gap-1.5 text-slate-400 text-sm">
                          <BatteryCharging className="w-4 h-4" />
                          <span>{device.battery}%</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Alerts Panel */}
              <div className="bg-[#0a0c12] rounded-2xl border border-slate-800 shadow-sm overflow-hidden">
                <div className="p-5 border-b border-slate-800">
                  <h2 className="font-semibold text-white">Recent Activity</h2>
                </div>
                <div className="divide-y divide-slate-800 p-2">
                  {mockAlerts.map(alert => (
                    <div key={alert.id} className="p-3 flex items-start gap-3 hover:bg-slate-800/50 rounded-lg transition-colors">
                      <div className={`mt-0.5 w-1.5 h-1.5 rounded-full flex-shrink-0 shadow-sm ${
                        alert.type === 'warning' ? 'bg-orange-500 shadow-orange-500/50' : 
                        alert.type === 'emergency' ? 'bg-red-500 shadow-red-500/50' : 'bg-cyan-500 shadow-cyan-500/50'
                      }`} />
                      <div>
                        <p className="text-sm text-slate-300 leading-snug">{alert.message}</p>
                        <p className="text-xs text-slate-500 mt-1">{alert.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: Analytics & Map Placeholder */}
            <div className="lg:col-span-2 space-y-8">
              
              {/* Analytics Chart */}
              <div className="bg-[#0a0c12] rounded-2xl border border-slate-800 shadow-sm overflow-hidden p-6 relative">
                <div className="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none">
                  <div className="w-full h-full border-[0.5px] border-cyan-500/50 [background-image:radial-gradient(circle_at_2px_2px,rgba(6,182,212,0.2)_1px,transparent_0)] [background-size:24px_24px]"></div>
                </div>
                <div className="mb-6 relative z-10">
                  <h2 className="font-semibold text-white">Connection Stability</h2>
                  <p className="text-sm text-slate-400">Active BLE device links over the last 12 hours.</p>
                </div>
                <div className="h-64 w-full relative z-10">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={mockActivityData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorConnections" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.2}/>
                          <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                      <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '8px', border: '1px solid #1e293b', backgroundColor: '#0f172a', boxShadow: '0 4px 15px -1px rgba(6,182,212,0.1)' }}
                        itemStyle={{ color: '#f8fafc', fontWeight: 500 }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="connections" 
                        stroke="#06b6d4" 
                        strokeWidth={2}
                        fillOpacity={1} 
                        fill="url(#colorConnections)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Location/Map Placeholder */}
              <div className="bg-[#0a0c12] rounded-2xl border border-slate-800 shadow-sm overflow-hidden relative">
                <div className="p-5 border-b border-slate-800 flex justify-between items-center bg-[#0a0c12]/80 backdrop-blur-sm absolute top-0 w-full z-10">
                  <h2 className="font-semibold text-white flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-cyan-500" />
                    Last Known Location
                  </h2>
                  <span className="px-2.5 py-1 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-medium rounded-full">Tracking Active</span>
                </div>
                {/* Simulated Map Background */}
                <div className="h-72 w-full bg-slate-900 relative overflow-hidden flex items-center justify-center">
                  {/* Fake Grid lines */}
                  <div className="absolute inset-0" style={{ backgroundImage: 'linear-gradient(#1e293b 1px, transparent 1px), linear-gradient(90deg, #1e293b 1px, transparent 1px)', backgroundSize: '40px 40px', opacity: 0.5 }}></div>
                  
                  {/* Fake Location Marker */}
                  <div className="relative z-10 flex flex-col items-center">
                    <div className="w-16 h-16 bg-cyan-500/20 rounded-full flex items-center justify-center animate-ping absolute opacity-50"></div>
                    <div className="w-8 h-8 bg-cyan-500 rounded-full border-4 border-[#0a0c12] shadow-[0_0_15px_rgba(6,182,212,0.5)] relative z-10"></div>
                    <div className="mt-2 bg-slate-800 px-3 py-1.5 rounded-lg shadow-sm border border-slate-700 text-xs font-medium text-slate-300 relative z-10">
                      Updated just now
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
