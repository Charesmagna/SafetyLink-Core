import React, { useEffect, useState } from 'react';
import { Shield, Smartphone, Activity, ArrowRight, Server, CheckCircle2, ChevronRight, Menu, X, Code2, Map, BellRing, Link as LinkIcon, Cpu, Zap, Camera, ShieldAlert, LineChart, Globe, Terminal, PlayCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router';

const DashboardMockup = () => (
  <div className="relative w-full max-w-lg lg:max-w-xl mx-auto lg:mr-0 aspect-[4/3] rounded-2xl border border-slate-700/50 bg-slate-900/80 backdrop-blur-xl shadow-2xl overflow-hidden shadow-emerald-900/20 transform lg:rotate-2 hover:rotate-0 transition-transform duration-500">
    {/* Top bar */}
    <div className="h-12 border-b border-slate-800 flex items-center px-4 justify-between bg-slate-950/80">
      <div className="flex gap-2">
        <div className="w-3 h-3 rounded-full bg-red-500/80" />
        <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
        <div className="w-3 h-3 rounded-full bg-green-500/80" />
      </div>
      <div className="text-xs font-mono text-emerald-500 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
        SYSTEM ONLINE
      </div>
    </div>
    
    {/* Background Grid */}
    <div className="absolute inset-0 top-12 bg-slate-950 z-0">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20" />
    </div>

    {/* Map Area */}
    <div className="absolute inset-0 top-12 z-10 p-6 flex flex-col gap-4">
      {/* Alert Card 1 */}
      <motion.div 
        initial={{ x: 50, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.5, type: 'spring' }}
        className="bg-slate-900/90 border border-red-500/30 rounded-xl p-4 flex gap-4 shadow-lg shadow-red-900/20 backdrop-blur-md"
      >
        <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center shrink-0 border border-red-500/30">
          <ShieldAlert className="w-6 h-6 text-red-500 animate-pulse" />
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-start mb-1">
            <h4 className="text-sm font-bold text-slate-100 uppercase tracking-wide">Critical: Panic Trigger</h4>
            <span className="text-[10px] px-2 py-0.5 rounded bg-red-500/20 text-red-400 font-mono border border-red-500/20">LIVE</span>
          </div>
          <p className="text-xs text-slate-400 font-mono">ID: AL-9842 • Sector 4</p>
          <div className="mt-3 flex gap-2">
            <div className="h-1.5 flex-1 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-red-500 w-3/4"></div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Guard Patrol 2 */}
      <motion.div 
        initial={{ x: 50, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.7, type: 'spring' }}
        className="bg-slate-900/90 border border-slate-700/50 rounded-xl p-4 flex gap-4 shadow-lg backdrop-blur-md"
      >
        <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0 border border-emerald-500/30">
          <Map className="w-6 h-6 text-emerald-500" />
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-start mb-1">
            <h4 className="text-sm font-bold text-slate-100 uppercase tracking-wide">Patrol Check-in</h4>
            <span className="text-[10px] text-emerald-400 font-mono">00:03:45</span>
          </div>
          <p className="text-xs text-slate-400 font-mono">Unit Delta • All Clear</p>
        </div>
      </motion.div>
      
      {/* CCTV Detection 3 */}
      <motion.div 
        initial={{ x: 50, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.9, type: 'spring' }}
        className="bg-slate-900/90 border border-orange-500/30 rounded-xl p-4 flex gap-4 shadow-lg shadow-orange-900/20 backdrop-blur-md"
      >
        <div className="w-12 h-12 rounded-full bg-orange-500/20 flex items-center justify-center shrink-0 border border-orange-500/30">
          <Camera className="w-6 h-6 text-orange-500" />
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-start mb-1">
            <h4 className="text-sm font-bold text-slate-100 uppercase tracking-wide">AI Motion Detected</h4>
            <span className="text-[10px] text-orange-400 font-mono">00:05:10</span>
          </div>
          <p className="text-xs text-slate-400 font-mono">Cam 04 • Perimeter Breach</p>
        </div>
      </motion.div>
    </div>
  </div>
);

const TechTicker = () => (
  <div className="w-full overflow-hidden flex whitespace-nowrap bg-slate-950 border-y border-slate-900 py-5 relative">
    <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-slate-950 to-transparent z-10" />
    <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-slate-950 to-transparent z-10" />
    <motion.div 
      className="flex gap-16 items-center px-6"
      animate={{ x: ["0%", "-50%"] }}
      transition={{ duration: 25, ease: "linear", repeat: Infinity }}
    >
      {[...Array(2)].map((_, j) => (
        <React.Fragment key={j}>
           <div className="text-slate-400 font-bold tracking-widest text-xs flex items-center gap-2"><Globe className="w-4 h-4 text-slate-600"/> SUPABASE CLOUD</div>
           <div className="text-slate-400 font-bold tracking-widest text-xs flex items-center gap-2"><Activity className="w-4 h-4 text-slate-600"/> TWILIO SMS/VOICE</div>
           <div className="text-slate-400 font-bold tracking-widest text-xs flex items-center gap-2"><Zap className="w-4 h-4 text-slate-600"/> FIREBASE FCM</div>
           <div className="text-slate-400 font-bold tracking-widest text-xs flex items-center gap-2"><Smartphone className="w-4 h-4 text-slate-600"/> CAPACITOR NATIVE</div>
           <div className="text-slate-400 font-bold tracking-widest text-xs flex items-center gap-2"><Server className="w-4 h-4 text-slate-600"/> BULLMQ WORKERS</div>
           <div className="text-slate-400 font-bold tracking-widest text-xs flex items-center gap-2"><Camera className="w-4 h-4 text-slate-600"/> WEBRTC VIDEO</div>
        </React.Fragment>
      ))}
    </motion.div>
  </div>
);

export const LandingPage = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeFeatureTab, setActiveFeatureTab] = useState('incident');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const featureTabs = [
    { id: 'incident', label: 'Incident Command', icon: <ShieldAlert className="w-4 h-4" /> },
    { id: 'field', label: 'Field Operations', icon: <Map className="w-4 h-4" /> },
    { id: 'integrations', label: 'Systems Integration', icon: <LinkIcon className="w-4 h-4" /> },
    { id: 'alerts', label: 'Automated Escalation', icon: <BellRing className="w-4 h-4" /> },
    { id: 'analytics', label: 'Geospatial Analytics', icon: <LineChart className="w-4 h-4" /> },
    { id: 'ai', label: 'Edge AI Processing', icon: <Cpu className="w-4 h-4" /> },
  ];

  const featureContent: Record<string, { title: string, subtitle: string, features: {title: string, desc: string}[], code: string }> = {
    incident: {
      title: 'Incident Command Center',
      subtitle: 'Centralized situational awareness for rapid decision making.',
      features: [
        { title: 'Live Workflow Board', desc: 'Track alerts from creation to resolution with real-time UI updates.' },
        { title: 'Global Guard Tracking', desc: 'GPS-based monitoring of field staff with offline state persistence.' },
        { title: 'Emergency Dispatch', desc: 'Coordinate police, fire, and medical response through integrated channels.' },
        { title: 'Escalation Policies', desc: 'Ensure critical alerts are acknowledged via strict organizational rules.' }
      ],
      code: `// POST /api/incidents
fetch('/api/incidents', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    type: 'panic_alert',
    status: 'critical',
    location: { lat: -29.8587, lng: 31.0218 },
    priority_routing: true
  })
});`
    },
    field: {
      title: 'Field Operations Engine',
      subtitle: 'Native mobile capabilities engineered for reliability in low-signal environments.',
      features: [
        { title: 'Mobile Guard App', desc: 'Submit incident notes, photos, and status updates via Capacitor native bridge.' },
        { title: 'Panic Button Trigger', desc: 'Instant SOS citizen alerts bypassing the lock screen via Android accessibility APIs.' },
        { title: 'Wearable Integration', desc: 'BLE connectivity for pendants, fall detectors, and external GPS trackers.' }
      ],
      code: `// POST /api/reports
fetch('/api/reports', {
  method: 'POST',
  body: JSON.stringify({
    guard_id: 'G-74892',
    report_type: 'suspicious_activity',
    notes: 'Perimeter breach near sector B.',
    encrypted_blob: '/uploads/secure/report123.enc'
  })
});`
    },
    integrations: {
      title: 'Systems Integration Layer',
      subtitle: 'Connect existing hardware and software seamlessly into one pane of glass.',
      features: [
        { title: 'IoT Sensor Mesh', desc: 'Ingest events from motion, smoke, and vibration detection hardware.' },
        { title: 'CCTV Video Feeds', desc: 'RTSP/WebRTC live video monitoring integration directly into the dashboard.' },
        { title: 'Bi-Directional Webhooks', desc: 'Connect external security platforms and CRMs effortlessly.' },
        { title: 'Hardware Fallbacks', desc: 'Dual SIM 4G router integration for control room reliability.' }
      ],
      code: `// Webhook Handler
app.post('/webhook/iot', (req, res) => {
  const { sensor_id, type, timestamp } = req.body;
  // Push to BullMQ for immediate background dispatch
  dispatchQueue.add('sensor_alert', { sensor_id, type });
  res.sendStatus(202);
});`
    },
    alerts: {
      title: 'Automated Escalation Matrix',
      subtitle: 'Never miss a critical event. Sequential fallbacks guarantee message delivery.',
      features: [
        { title: 'FCM Push & Polling', desc: 'Immediate app wake utilizing high-priority Firebase Cloud Messaging.' },
        { title: 'SMS & Voice Fallback', desc: 'Twilio integration calls responders if the push notification goes unacknowledged.' },
        { title: 'Duty Rosters', desc: 'Dynamic routing based on active shifts and geolocation proximity.' },
        { title: 'AI False-Positive Filter', desc: 'Machine learning heuristics reduce alert fatigue by scoring anomalies.' }
      ],
      code: `// Escalation Engine
async function escalate(alertId, users) {
  for (const user of users) {
    await sendPush(user, alertId);
    if (!await isAcknowledged(alertId, 30)) {
       await sendSms(user, alertId);
       if (!await isAcknowledged(alertId, 60)) {
          await triggerVoiceCall(user, alertId);
       }
    }
  }
}`
    },
    analytics: {
      title: 'Geospatial Analytics',
      subtitle: 'Transform raw incident data into actionable security intelligence.',
      features: [
        { title: 'Crime Heatmaps', desc: 'Visualize geospatial hotspots with hardware-accelerated WebGL layers.' },
        { title: 'Compliance Reporting', desc: 'Generate exportable PDF reports for SLA and standard audits.' },
        { title: 'Response Metrics', desc: 'Track time-to-acknowledge and time-to-dispatch metrics organization-wide.' },
        { title: 'Automated Penetration Tests', desc: 'Monthly system reliability checks and health heartbeat monitors.' }
      ],
      code: `// GET /api/analytics/heatmap
fetch('/api/analytics/heatmap?timeframe=30d')
  .then(res => res.json())
  .then(data => {
    // Render WebGL heatmap layer
    map.addLayer(new HeatmapLayer(data.nodes));
  });`
    },
    ai: {
      title: 'Edge AI Processing',
      subtitle: 'Next-generation neural networks running directly on field hardware.',
      features: [
        { title: 'Video Analytics', desc: 'Detect suspicious behavior, loitering, and weapons on the edge.' },
        { title: 'Facial Recognition', desc: 'Opt-in biometric access control for secure facility perimeters.' },
        { title: 'Immutable Audit Logs', desc: 'Cryptographically signed incident logs for court-admissible evidence.' },
        { title: 'NLP Voice Dispatch', desc: 'Trigger complex command operations using natural language.' }
      ],
      code: `// TensorFlow/OpenCV Edge Processing
import cv2
import ai_models

camera = cv2.VideoCapture(0)
while True:
    ret, frame = camera.read()
    if ai_models.detect_threat(frame, confidence=0.85):
        api.trigger_incident("CCTV_AI", "weapon_detected")`
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white selection:bg-emerald-500/30 font-sans">
      
      {/* Navigation */}
      <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-slate-950/90 backdrop-blur-xl border-b border-slate-800/80 py-4 shadow-xl' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <img src="/assets/New%20SafetyLink%20Official%20Logo.svg" alt="SafetyLink Logo" className="h-8 transition-transform duration-500 group-hover:scale-105" />
          </Link>
          
          <nav className="hidden md:flex items-center gap-10 text-sm font-semibold text-slate-300 tracking-wide">
            <a href="#platform" className="hover:text-emerald-400 transition-colors">Platform</a>
            <a href="#infrastructure" className="hover:text-emerald-400 transition-colors">Infrastructure</a>
            <a href="#solutions" className="hover:text-emerald-400 transition-colors">Solutions</a>
            <a href="#pricing" className="hover:text-emerald-400 transition-colors">Licensing</a>
          </nav>

          <div className="hidden md:flex items-center gap-5 text-sm font-bold">
            <Link to="/login" className="text-slate-300 hover:text-white transition-colors">Sign In</Link>
            <Link to="/register" className="bg-white text-slate-950 hover:bg-emerald-400 px-6 py-2.5 rounded-full transition-colors flex items-center gap-2 shadow-[0_0_20px_rgba(255,255,255,0.1)]">
              Contact Sales <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <button className="md:hidden text-slate-300" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-slate-950 pt-24 px-6 md:hidden"
          >
            <div className="flex flex-col gap-6 text-xl font-bold">
              <a href="#platform" onClick={() => setMobileMenuOpen(false)}>Platform</a>
              <a href="#infrastructure" onClick={() => setMobileMenuOpen(false)}>Infrastructure</a>
              <a href="#solutions" onClick={() => setMobileMenuOpen(false)}>Solutions</a>
              <div className="h-px w-full bg-slate-800 my-4" />
              <Link to="/login" className="text-slate-400" onClick={() => setMobileMenuOpen(false)}>Sign In</Link>
              <Link to="/register" className="bg-emerald-500 text-slate-950 text-center py-4 rounded-xl shadow-lg mt-2" onClick={() => setMobileMenuOpen(false)}>Create Organization</Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden border-b border-slate-900">
        <video 
          autoPlay 
          muted 
          loop 
          playsInline 
          className="absolute inset-0 w-full h-full object-cover z-0 opacity-20 mix-blend-screen scale-105"
        >
          <source src="/assets/SafetyLink%203D%20Animation%20Logo.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-slate-950/80 to-slate-950 z-0" />
        
        <div className="max-w-7xl mx-auto px-6 relative z-10 w-full">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="lg:w-1/2"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900 border border-slate-700 text-slate-300 text-xs font-bold mb-6 tracking-widest uppercase shadow-lg">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Enterprise Command Software
              </div>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight mb-8 leading-[1.1]">
                Respond Faster. <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-500">Zero Downtime.</span>
              </h1>
              <p className="text-lg md:text-xl text-slate-400 mb-10 max-w-xl leading-relaxed">
                The most resilient incident management and dispatch platform. Designed for B2B security firms, neighborhood watches, and mission-critical emergency response.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/register" className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-8 py-4 rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(16,185,129,0.3)]">
                  Start Your Free Trial
                </Link>
                <a href="#platform" className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-2 backdrop-blur-sm">
                  View Features
                </a>
              </div>
            </motion.div>
            
            <div className="lg:w-1/2 w-full mt-10 lg:mt-0">
              <DashboardMockup />
            </div>
          </div>
        </div>
      </section>

      {/* Tech Ticker */}
      <TechTicker />

      {/* Bento Grid Features */}
      <section id="infrastructure" className="py-24 bg-slate-950 border-b border-slate-900">
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4 tracking-tight">Built for Mission-Critical Teams</h2>
            <p className="text-lg text-slate-400 max-w-2xl">A robust monolith separating background processing from UI rendering, utilizing modern native bridging for Android capabilities.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Big Feature */}
            <div className="md:col-span-2 bg-slate-900 rounded-[2rem] p-8 md:p-12 border border-slate-800 relative overflow-hidden group hover:border-emerald-500/30 transition-colors">
              <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 blur-[100px] pointer-events-none rounded-full" />
              <Server className="w-10 h-10 text-emerald-500 mb-6 relative z-10" />
              <h3 className="text-2xl font-bold text-white mb-4 relative z-10">Decoupled Dispatch Engine</h3>
              <p className="text-slate-400 text-lg leading-relaxed relative z-10 max-w-xl mb-8">
                Separated backend worker processes (BullMQ) handle massive I/O operations without blocking the UI thread. Ensures SMS and Voice fallbacks fire even if web sockets drop.
              </p>
              <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 font-mono text-sm text-slate-300 relative z-10">
                <span className="text-emerald-400">INFO</span> [Worker] Dispatching alert AL-9842... <br/>
                <span className="text-emerald-400">INFO</span> [Twilio] Voice call initiated to +2782*** <br/>
                <span className="text-slate-500">WAIT</span> Awaiting acknowledgment...
              </div>
            </div>
            
            {/* Tall Feature */}
            <div className="bg-slate-900 rounded-[2rem] p-8 md:p-12 border border-slate-800 relative overflow-hidden group hover:border-slate-700 transition-colors flex flex-col">
              <Smartphone className="w-10 h-10 text-white mb-6" />
              <h3 className="text-2xl font-bold text-white mb-4">Native Hardware</h3>
              <p className="text-slate-400 text-lg leading-relaxed flex-1">
                Compiled Android 15 SDK utilizing Capacitor 6. Custom foreground syncs and direct filesystem caching for offline persistence.
              </p>
            </div>

            {/* Medium Features */}
            <div className="bg-slate-900 rounded-[2rem] p-8 border border-slate-800 hover:border-slate-700 transition-colors">
              <Activity className="w-8 h-8 text-emerald-500 mb-6" />
              <h3 className="text-xl font-bold text-white mb-3">Optimized Zustand State</h3>
              <p className="text-slate-400">Massive domain-sliced offline state matrices prevent frame drops, maintaining 60FPS.</p>
            </div>
            <div className="bg-slate-900 rounded-[2rem] p-8 border border-slate-800 hover:border-slate-700 transition-colors">
              <Lock className="w-8 h-8 text-white mb-6" />
              <h3 className="text-xl font-bold text-white mb-3">End-to-End Encryption</h3>
              <p className="text-slate-400">AES-256 encrypted payload transit. Complete organizational data isolation and compliance.</p>
            </div>
            <div className="bg-slate-900 rounded-[2rem] p-8 border border-slate-800 hover:border-slate-700 transition-colors">
              <Zap className="w-8 h-8 text-emerald-500 mb-6" />
              <h3 className="text-xl font-bold text-white mb-3">IoT Ready</h3>
              <p className="text-slate-400">Webhooks to consume hardware alerts instantly from smart fences or localized panic remotes.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Comprehensive SaaS Tabs (Platform Deep Dive) */}
      <section id="platform" className="py-32 bg-slate-950 relative border-b border-slate-900">
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">The Complete Operations Suite</h2>
            <p className="text-lg text-slate-400">
              SafetyLink unites incident dispatch, field reporting, and external hardware into a single pane of glass, engineered for absolute clarity under pressure.
            </p>
          </div>

          <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
            {/* Tabs Sidebar */}
            <div className="lg:w-1/3 flex flex-col gap-3">
              {featureTabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveFeatureTab(tab.id)}
                  className={`flex items-center gap-4 px-6 py-5 rounded-2xl text-left font-bold transition-all border ${activeFeatureTab === tab.id ? 'bg-slate-900 border-emerald-500/50 text-white shadow-xl shadow-emerald-900/10' : 'bg-transparent border-transparent text-slate-500 hover:bg-slate-900 hover:text-slate-300'}`}
                >
                  <div className={`p-2 rounded-lg ${activeFeatureTab === tab.id ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                    {tab.icon}
                  </div>
                  <span className="text-lg">{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Tab Content Area */}
            <div className="lg:w-2/3">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeFeatureTab}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="bg-slate-900 rounded-[2rem] border border-slate-800 p-8 md:p-10 shadow-2xl"
                >
                  <h3 className="text-3xl font-bold mb-3 tracking-tight text-white">
                    {featureContent[activeFeatureTab].title}
                  </h3>
                  <p className="text-slate-400 mb-10 text-lg">{featureContent[activeFeatureTab].subtitle}</p>
                  
                  <div className="grid sm:grid-cols-2 gap-8 mb-12">
                    {featureContent[activeFeatureTab].features.map((feature, i) => (
                      <div key={i}>
                        <h4 className="font-bold text-white mb-2 flex items-center gap-2">
                          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                          {feature.title}
                        </h4>
                        <p className="text-slate-400 text-sm leading-relaxed pl-7">{feature.desc}</p>
                      </div>
                    ))}
                  </div>

                  {/* Code Snippet */}
                  <div className="rounded-2xl overflow-hidden border border-slate-800 bg-[#0d1117] shadow-inner">
                    <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800/50 bg-[#161b22]">
                      <div className="flex items-center gap-2 text-slate-400 text-xs font-mono font-bold tracking-wider">
                        <Terminal className="w-4 h-4" />
                        DEVELOPER API
                      </div>
                    </div>
                    <div className="p-6 overflow-x-auto">
                      <pre className="text-sm font-mono text-emerald-400/90 leading-relaxed">
                        <code>{featureContent[activeFeatureTab].code}</code>
                      </pre>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </section>

      {/* Solutions / Video Cards */}
      <section id="solutions" className="py-32 bg-slate-950 border-b border-slate-900">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">Trusted by Industry Leaders</h2>
            <p className="text-lg text-slate-400">Deployed across individual care sectors and large-scale community security organizations throughout South Africa.</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-10">
            <div className="bg-slate-900 rounded-[2rem] border border-slate-800 overflow-hidden group hover:border-slate-700 transition-colors shadow-2xl flex flex-col">
              <div className="aspect-[16/9] relative bg-slate-950 overflow-hidden border-b border-slate-800">
                <video autoPlay muted loop playsInline className="w-full h-full object-cover opacity-60 group-hover:opacity-90 group-hover:scale-105 transition-all duration-700">
                  <source src="/assets/video.mp4" type="video/mp4" />
                </video>
                <div className="absolute top-6 left-6 bg-slate-900/90 backdrop-blur border border-slate-700 text-xs font-bold px-4 py-2 rounded-full flex items-center gap-2 text-white shadow-lg uppercase tracking-widest">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> B2B Network
                </div>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                   <div className="w-16 h-16 rounded-full bg-slate-900/80 backdrop-blur border border-slate-700 flex items-center justify-center text-white cursor-pointer hover:bg-emerald-500 hover:text-slate-950 transition-colors">
                     <PlayCircle className="w-8 h-8" />
                   </div>
                </div>
              </div>
              <div className="p-10 flex-1 flex flex-col justify-center">
                <h3 className="text-3xl font-bold text-white mb-4">Security Firms & CPOs</h3>
                <p className="text-slate-400 leading-relaxed text-lg">Seamless integration for neighborhood watches and private security. Handles massive rosters of residents with instant routing to dedicated armed response vehicles via GPS coordinates.</p>
              </div>
            </div>

            <div className="bg-slate-900 rounded-[2rem] border border-slate-800 overflow-hidden group hover:border-slate-700 transition-colors shadow-2xl flex flex-col">
              <div className="aspect-[16/9] relative bg-slate-950 overflow-hidden border-b border-slate-800">
                <video autoPlay muted loop playsInline className="w-full h-full object-cover opacity-60 group-hover:opacity-90 group-hover:scale-105 transition-all duration-700">
                  <source src="/assets/video%20(3).mp4" type="video/mp4" />
                </video>
                <div className="absolute top-6 left-6 bg-slate-900/90 backdrop-blur border border-slate-700 text-xs font-bold px-4 py-2 rounded-full flex items-center gap-2 text-white shadow-lg uppercase tracking-widest">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span> Vulnerable Care
                </div>
              </div>
              <div className="p-10 flex-1 flex flex-col justify-center">
                <h3 className="text-3xl font-bold text-white mb-4">Elderly & Family Safety</h3>
                <p className="text-slate-400 leading-relaxed text-lg">Designed for vulnerable individuals home alone. Instant alerts to family members with one touch, leveraging the 30s-90s pipeline to guarantee delivery if data connectivity drops.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing / Licensing */}
      <section id="pricing" className="py-32 bg-slate-950 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-emerald-900/10 blur-[150px] rounded-full pointer-events-none" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">Transparent Licensing</h2>
            <p className="text-lg text-slate-400">Enterprise-grade infrastructure available at any scale. No hidden fees.</p>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Tier 1 */}
            <div className="bg-slate-900/50 p-10 rounded-[2.5rem] border border-slate-800 flex flex-col hover:border-slate-700 transition-colors backdrop-blur-sm">
              <h3 className="text-2xl font-bold text-white mb-2">Individual Coverage</h3>
              <p className="text-slate-400 text-sm mb-8">Perfect for single users requiring reliable monitoring.</p>
              <div className="text-5xl font-extrabold text-white mb-10">R49<span className="text-xl text-slate-500 font-normal">/mo</span></div>
              <ul className="space-y-5 mb-12 flex-1 text-slate-300 font-medium">
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>1 Monitored Device</span></li>
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>Standard FCM & SMS alerts</span></li>
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>24-hour incident history</span></li>
              </ul>
              <button className="w-full py-4 rounded-2xl font-bold bg-slate-800 text-white hover:bg-slate-700 transition-colors text-lg">Select Plan</button>
            </div>
            
            {/* Tier 2 */}
            <div className="bg-slate-900 p-10 rounded-[2.5rem] border border-emerald-500 relative flex flex-col transform lg:-translate-y-6 shadow-[0_20px_60px_rgba(16,185,129,0.15)] z-10">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-emerald-500 text-slate-950 text-xs font-bold px-6 py-2 rounded-full uppercase tracking-widest shadow-lg">Most Popular</div>
              <h3 className="text-2xl font-bold text-white mb-2">Family Network</h3>
              <p className="text-slate-400 text-sm mb-8">Comprehensive protection for the whole household.</p>
              <div className="text-5xl font-extrabold text-white mb-10">R99<span className="text-xl text-slate-500 font-normal">/mo</span></div>
              <ul className="space-y-5 mb-12 flex-1 text-slate-300 font-medium">
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>Up to 5 Devices</span></li>
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>Priority Voice Escalation (Twilio)</span></li>
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>Live WebRTC Video tracking</span></li>
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>30-day incident history</span></li>
              </ul>
              <Link to="/register" className="block text-center w-full py-4 rounded-2xl font-bold bg-emerald-500 text-slate-950 hover:bg-emerald-400 transition-colors shadow-lg text-lg">Start Protection</Link>
            </div>
            
            {/* Tier 3 */}
            <div className="bg-slate-900/50 p-10 rounded-[2.5rem] border border-slate-800 flex flex-col hover:border-slate-700 transition-colors backdrop-blur-sm">
              <h3 className="text-2xl font-bold text-white mb-2">Enterprise / B2B</h3>
              <p className="text-slate-400 text-sm mb-8">Advanced features for large security firms & CPOs.</p>
              <div className="text-5xl font-extrabold text-white mb-10">Custom</div>
              <ul className="space-y-5 mb-12 flex-1 text-slate-300 font-medium">
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>Unlimited user rosters</span></li>
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>Tactical Incident Board access</span></li>
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>Dedicated BullMQ priority queues</span></li>
                <li className="flex gap-4 items-start"><CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0"/> <span>Custom Webhook Integrations</span></li>
              </ul>
              <button className="w-full py-4 rounded-2xl font-bold bg-slate-800 text-white hover:bg-slate-700 transition-colors text-lg">Contact Sales</button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#020617] border-t border-slate-900 pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-12 mb-20">
            <div className="col-span-2 md:col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <img src="/assets/New%20SafetyLink%20Official%20Logo.svg" alt="" className="h-10" />
                <span className="font-bold text-2xl tracking-tight text-white">SafetyLink Core</span>
              </div>
              <p className="text-slate-400 text-base max-w-sm mb-10 leading-relaxed">
                The leading Sequential Emergency Alert Network designed for high-stress offline scenarios. Engineered to save lives when seconds matter most.
              </p>
              <div className="flex flex-col gap-3">
                <span className="text-xs font-bold text-slate-500 tracking-widest uppercase">Technology Partner</span>
                <img src="/assets/Kleva.svg" alt="K'lev.ai" className="h-6 object-contain object-left opacity-70 hover:opacity-100 transition-opacity" />
              </div>
            </div>
            
            <div className="col-span-1">
              <h4 className="font-bold text-white text-base tracking-wide mb-6 uppercase">Product</h4>
              <ul className="space-y-4 text-base text-slate-400 font-medium">
                <li><Link to="/login" className="hover:text-emerald-400 transition-colors">Admin Portal</Link></li>
                <li><a href="#platform" className="hover:text-emerald-400 transition-colors">Incident Board</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Mobile App (APK)</a></li>
                <li><a href="#pricing" className="hover:text-emerald-400 transition-colors">Pricing</a></li>
              </ul>
            </div>
            
            <div className="col-span-1">
              <h4 className="font-bold text-white text-base tracking-wide mb-6 uppercase">Developers</h4>
              <ul className="space-y-4 text-base text-slate-400 font-medium">
                <li><a href="#" className="hover:text-emerald-400 transition-colors">API Documentation</a></li>
                <li><a href="#infrastructure" className="hover:text-emerald-400 transition-colors">Architecture Overview</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Webhooks</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">System Status</a></li>
              </ul>
            </div>
            
            <div className="col-span-1">
              <h4 className="font-bold text-white text-base tracking-wide mb-6 uppercase">Company</h4>
              <ul className="space-y-4 text-base text-slate-400 font-medium">
                <li><a href="#" className="hover:text-emerald-400 transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Contact Sales</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-800/50 pt-8 flex flex-col md:flex-row items-center justify-between gap-6 text-sm text-slate-500 font-medium">
            <p>© 2026 TM Media Solutions & K'lev.ai Partners. All rights reserved.</p>
            <div className="flex gap-8">
              <a href="#" className="hover:text-slate-300 transition-colors">Twitter</a>
              <a href="#" className="hover:text-slate-300 transition-colors">LinkedIn</a>
              <a href="#" className="hover:text-slate-300 transition-colors">GitHub</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
