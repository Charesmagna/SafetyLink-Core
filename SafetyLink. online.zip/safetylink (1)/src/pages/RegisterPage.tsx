import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router';
import { Shield, Building2, User, KeyRound, Mail, ArrowRight, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export const RegisterPage = () => {
  const [formData, setFormData] = useState({
    orgName: '',
    orgCode: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    // Simulate network request
    setTimeout(() => {
      setLoading(false);
      navigate('/login');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Left Column - Form */}
      <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:flex-none lg:w-[600px] lg:px-20 xl:px-24">
        <div className="mx-auto w-full max-w-sm lg:w-96">
          <div>
            <Link to="/" className="flex items-center gap-2 mb-8 group">
              <img src="/assets/New%20SafetyLink%20Official%20Logo.svg" alt="SafetyLink Logo" className="h-8 transition-transform group-hover:scale-105" />
            </Link>
            <h2 className="mt-8 text-3xl font-extrabold text-white tracking-tight">Create Organization</h2>
            <p className="mt-2 text-sm text-slate-400">
              Already registered?{' '}
              <Link to="/login" className="font-medium text-emerald-500 hover:text-emerald-400 transition-colors">
                Sign in to your dashboard
              </Link>
            </p>
          </div>

          <div className="mt-8">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <form onSubmit={handleRegister} className="space-y-5">
                {error && (
                  <div className="p-3 bg-red-950/50 border border-red-500/50 rounded-lg text-red-400 text-sm flex items-start gap-2">
                    <Shield className="w-4 h-4 mt-0.5 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}
                
                <div>
                  <label className="block text-sm font-medium text-slate-300">Organization Name</label>
                  <div className="mt-1 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Building2 className="h-5 w-5 text-slate-500" />
                    </div>
                    <input
                      type="text"
                      required
                      className="appearance-none block w-full pl-10 pr-3 py-2.5 border border-slate-700 rounded-lg shadow-sm placeholder-slate-500 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 bg-slate-900/50 text-white sm:text-sm transition-colors"
                      placeholder="Moira Park Neighborhood Watch"
                      value={formData.orgName}
                      onChange={e => setFormData({...formData, orgName: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300">Admin Email</label>
                  <div className="mt-1 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-slate-500" />
                    </div>
                    <input
                      type="email"
                      required
                      className="appearance-none block w-full pl-10 pr-3 py-2.5 border border-slate-700 rounded-lg shadow-sm placeholder-slate-500 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 bg-slate-900/50 text-white sm:text-sm transition-colors"
                      placeholder="admin@moirapark.org"
                      value={formData.email}
                      onChange={e => setFormData({...formData, email: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300">Desired Organization Code (Unique ID)</label>
                  <div className="mt-1 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User className="h-5 w-5 text-slate-500" />
                    </div>
                    <input
                      type="text"
                      required
                      className="appearance-none block w-full pl-10 pr-3 py-2.5 border border-slate-700 rounded-lg shadow-sm placeholder-slate-500 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 bg-slate-900/50 text-white sm:text-sm transition-colors uppercase font-mono"
                      placeholder="MOIRA-PARK-NW"
                      value={formData.orgCode}
                      onChange={e => setFormData({...formData, orgCode: e.target.value.toUpperCase()})}
                    />
                  </div>
                  <p className="mt-1 text-xs text-slate-500">Users will use this code to link their app to your network.</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300">Admin Password</label>
                  <div className="mt-1 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <KeyRound className="h-5 w-5 text-slate-500" />
                    </div>
                    <input
                      type="password"
                      required
                      className="appearance-none block w-full pl-10 pr-3 py-2.5 border border-slate-700 rounded-lg shadow-sm placeholder-slate-500 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 bg-slate-900/50 text-white sm:text-sm transition-colors"
                      placeholder="••••••••"
                      value={formData.password}
                      onChange={e => setFormData({...formData, password: e.target.value})}
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-300">Confirm Password</label>
                  <div className="mt-1 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <KeyRound className="h-5 w-5 text-slate-500" />
                    </div>
                    <input
                      type="password"
                      required
                      className="appearance-none block w-full pl-10 pr-3 py-2.5 border border-slate-700 rounded-lg shadow-sm placeholder-slate-500 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 bg-slate-900/50 text-white sm:text-sm transition-colors"
                      placeholder="••••••••"
                      value={formData.confirmPassword}
                      onChange={e => setFormData({...formData, confirmPassword: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-bold text-slate-950 bg-emerald-500 hover:bg-emerald-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed group mt-2"
                  >
                    {loading ? 'Provisioning Environment...' : 'Create Organization Network'}
                    {!loading && <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />}
                  </button>
                </div>
                
                <p className="text-xs text-slate-500 text-center mt-4">
                  By registering, you agree to SafetyLink's <a href="#" className="text-emerald-500 hover:underline">Terms of Service</a> and <a href="#" className="text-emerald-500 hover:underline">Privacy Policy</a>.
                </p>
              </form>
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* Right Column - Image & Info */}
      <div className="hidden lg:block relative w-0 flex-1 bg-slate-900 border-l border-slate-800 overflow-hidden">
        <div className="absolute inset-0">
          <img
            className="h-full w-full object-cover opacity-30 mix-blend-luminosity"
            src="/assets/IMG_20260721_115013.jpg"
            alt="Command Center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent" />
        </div>
        <div className="relative h-full flex flex-col justify-end p-12 lg:p-16 xl:p-24 text-white">
          <div className="max-w-2xl">
            <h2 className="text-3xl font-bold tracking-tight mb-6">Enterprise-Grade Emergency Infrastructure</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />
                <div>
                  <h4 className="font-semibold text-slate-200">Decoupled Dispatch Engine</h4>
                  <p className="text-slate-400 text-sm mt-1">BullMQ worker processes handle SMS and Voice fallbacks via Twilio even during web server instability.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />
                <div>
                  <h4 className="font-semibold text-slate-200">Real-Time WebRTC Video</h4>
                  <p className="text-slate-400 text-sm mt-1">ConnectyCube powered live streaming during high-priority active distress situations.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />
                <div>
                  <h4 className="font-semibold text-slate-200">Optimized Dashboard Access</h4>
                  <p className="text-slate-400 text-sm mt-1">Zero frame drops parsing massive organization arrays using our memoized rendering engine.</p>
                </div>
              </div>
            </div>
            
            <div className="mt-12 pt-8 border-t border-slate-800">
              <p className="text-slate-400 italic">"SafetyLink's offline-capable capacitor bridge fundamentally shifted how our neighborhood watch handles connectivity dropouts."</p>
              <div className="mt-4 flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center font-bold text-slate-300">MP</div>
                <div>
                  <div className="font-semibold text-sm">Moira Park Security</div>
                  <div className="text-xs text-slate-500">Early Access Partner</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
