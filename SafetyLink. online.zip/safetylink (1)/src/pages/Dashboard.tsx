import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Shield, Users, Activity, Settings, LogOut, Map, AlertTriangle } from 'lucide-react';
import type { User, PanicAlert, EventLog } from '../types';

// Fix Leaflet icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const redIcon = L.icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const defaultIcon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

export const Dashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('map');
  const [users, setUsers] = useState<User[]>([]);
  const [events, setEvents] = useState<EventLog[]>([]);
  const [panics, setPanics] = useState<PanicAlert[]>([]);
  
  const token = localStorage.getItem('safetylink_token');
  const orgStr = localStorage.getItem('safetylink_org');
  const org = orgStr ? JSON.parse(orgStr) : null;

  useEffect(() => {
    if (!token) {
      navigate('/login');
      return;
    }

    const fetchData = async () => {
      try {
        const headers = { 'Authorization': `Bearer ${token}` };
        
        const [uRes, pRes, eRes] = await Promise.all([
          fetch('/api/users', { headers }),
          fetch('/api/panic', { headers }),
          fetch('/api/events', { headers })
        ]);

        if (uRes.status === 401) {
          localStorage.removeItem('safetylink_token');
          navigate('/login');
          return;
        }

        const uData = await uRes.json();
        const pData = await pRes.json();
        const eData = await eRes.json();

        setUsers(uData.users || []);
        setPanics(pData.panics || []);
        setEvents(eData.events || []);
      } catch (err) {
        console.error('Failed to fetch dashboard data', err);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, [token, navigate]);

  const handleResolvePanic = async (id: number) => {
    try {
      await fetch('/api/panic/resolve', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify({ panic_id: id })
      });
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('safetylink_token');
    localStorage.removeItem('safetylink_org');
    navigate('/');
  };

  if (!org) return null;

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 overflow-hidden font-sans">
      {/* Sidebar */}
      <div className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col">
        <div className="p-6 border-b border-slate-800 flex items-center gap-3">
          <Shield className="w-8 h-8 text-emerald-500" />
          <div>
            <h1 className="font-bold text-white leading-tight">SafetyLink</h1>
            <p className="text-xs text-slate-400">Command Center</p>
          </div>
        </div>
        
        <div className="p-4 border-b border-slate-800 bg-slate-950/50">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Organization</p>
          <p className="font-medium text-emerald-400">{org.name}</p>
          <p className="text-xs text-slate-400 font-mono mt-1">{org.code}</p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <NavItem icon={<Map />} label="Live Map" active={activeTab === 'map'} onClick={() => setActiveTab('map')} />
          <NavItem icon={<Users />} label="Personnel" active={activeTab === 'users'} onClick={() => setActiveTab('users')} count={users.length} />
          <NavItem icon={<AlertTriangle />} label="Alerts" active={activeTab === 'alerts'} onClick={() => setActiveTab('alerts')} count={panics.length} alert={panics.length > 0} />
          <NavItem icon={<Activity />} label="Event Log" active={activeTab === 'events'} onClick={() => setActiveTab('events')} />
          <NavItem icon={<Settings />} label="Settings" active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />
        </nav>

        <div className="p-4 border-t border-slate-800">
          <button 
            onClick={handleLogout}
            className="flex items-center gap-3 w-full p-3 rounded-lg hover:bg-red-950/50 text-slate-400 hover:text-red-400 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Sign Out</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Topbar */}
        <header className="h-16 bg-slate-900/50 border-b border-slate-800 flex items-center justify-between px-8">
          <h2 className="text-xl font-bold capitalize text-white">
            {activeTab.replace('-', ' ')}
          </h2>
          <div className="flex items-center gap-4">
            {panics.length > 0 && (
              <div className="px-3 py-1 bg-red-500/20 text-red-400 border border-red-500/50 rounded-full text-sm font-bold animate-pulse flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" /> {panics.length} Active Alerts
              </div>
            )}
            <div className="px-3 py-1 bg-slate-800 rounded-full text-sm font-medium text-slate-300">
              {users.length} Users Online
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-auto relative">
          {activeTab === 'map' && (
            <div className="absolute inset-0 z-0">
              <MapContainer 
                center={[-26.2041, 28.0473]} // Default to Johannesburg
                zoom={11} 
                style={{ height: '100%', width: '100%', background: '#020617' }}
              >
                <TileLayer
                  url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
                />
                {users.map(u => (u.latitude && u.longitude) ? (
                  <Marker 
                    key={u.id} 
                    position={[u.latitude, u.longitude]}
                    icon={u.panic_status === 'active' ? redIcon : defaultIcon}
                  >
                    <Popup className="custom-popup">
                      <div className="p-1">
                        <h3 className="font-bold text-slate-900">{u.name}</h3>
                        <p className="text-slate-600 text-sm">{u.phone}</p>
                        {u.panic_status === 'active' && (
                          <div className="mt-2 text-red-600 font-bold text-sm bg-red-100 p-1 rounded text-center">
                            🚨 ACTIVE PANIC
                          </div>
                        )}
                      </div>
                    </Popup>
                  </Marker>
                ) : null)}
              </MapContainer>
            </div>
          )}

          {activeTab === 'users' && (
            <div className="p-8">
              <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-800/50 border-b border-slate-800 text-slate-400 text-sm">
                      <th className="p-4 font-medium">Name</th>
                      <th className="p-4 font-medium">Phone</th>
                      <th className="p-4 font-medium">Status</th>
                      <th className="p-4 font-medium">Location</th>
                      <th className="p-4 font-medium">Registered</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/50">
                    {users.map(u => (
                      <tr key={u.id} className={u.panic_status === 'active' ? 'bg-red-950/20' : 'hover:bg-slate-800/20'}>
                        <td className="p-4 font-medium text-white">{u.name}</td>
                        <td className="p-4 text-slate-400">{u.phone}</td>
                        <td className="p-4">
                          {u.panic_status === 'active' ? (
                            <span className="px-2 py-1 bg-red-500/20 text-red-400 text-xs font-bold rounded-full">PANIC</span>
                          ) : (
                            <span className="px-2 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-medium rounded-full">Active</span>
                          )}
                        </td>
                        <td className="p-4 text-slate-400 text-sm font-mono">
                          {u.latitude ? `${u.latitude.toFixed(4)}, ${u.longitude?.toFixed(4)}` : 'Unknown'}
                        </td>
                        <td className="p-4 text-slate-400 text-sm">{new Date(u.created_at).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'alerts' && (
            <div className="p-8 space-y-4">
              {panics.length === 0 ? (
                <div className="text-center p-12 bg-slate-900 rounded-2xl border border-slate-800 text-slate-400">
                  <Shield className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>No active panic alerts.</p>
                </div>
              ) : panics.map(p => (
                <div key={p.id} className="bg-red-950/40 border border-red-500/50 rounded-2xl p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center animate-pulse">
                      <AlertTriangle className="w-6 h-6 text-red-500" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white">{p.user_name}</h3>
                      <p className="text-red-300">{p.user_phone}</p>
                      <p className="text-sm text-slate-400 mt-1 font-mono">
                        {p.latitude}, {p.longitude} • {new Date(p.created_at).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={() => handleResolvePanic(p.id)}
                    className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-white font-medium rounded-xl transition-colors border border-slate-700"
                  >
                    Mark Resolved
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'events' && (
            <div className="p-8">
              <div className="space-y-4 max-w-4xl">
                {events.map(e => (
                  <div key={e.id} className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex gap-4 items-start">
                    <div className={`p-2 rounded-lg \${
                      e.type === 'panic' ? 'bg-red-500/20 text-red-500' :
                      e.type === 'login' ? 'bg-blue-500/20 text-blue-500' :
                      e.type === 'register' ? 'bg-emerald-500/20 text-emerald-500' :
                      'bg-slate-800 text-slate-400'
                    }`}>
                      <Activity className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-200">
                        {e.user_name && <span className="font-bold text-white">{e.user_name}: </span>}
                        {e.description}
                      </p>
                      <p className="text-xs text-slate-500 mt-1">{new Date(e.created_at).toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="p-8 max-w-2xl">
              <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 mb-8">
                <h3 className="text-lg font-bold text-white mb-6">Organization Details</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-slate-400 mb-1">Organization Name</label>
                    <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-slate-300 font-medium">
                      {org.name}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm text-slate-400 mb-1">Organization Code (For App Registration)</label>
                    <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-emerald-400 font-mono font-bold text-lg">
                      {org.code}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

const NavItem = ({ icon, label, active, onClick, count, alert }: any) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center justify-between p-3 rounded-lg transition-all \${
      active 
        ? 'bg-emerald-500/10 text-emerald-400' 
        : 'hover:bg-slate-800/50 text-slate-400 hover:text-slate-200'
    }`}
  >
    <div className="flex items-center gap-3">
      <div className={`\${active ? 'text-emerald-500' : 'text-slate-500'} \${alert ? 'text-red-500' : ''}`}>
        {icon}
      </div>
      <span className="font-medium">{label}</span>
    </div>
    {count !== undefined && (
      <span className={`text-xs font-bold px-2 py-0.5 rounded-full \${
        alert ? 'bg-red-500/20 text-red-500' : 'bg-slate-800 text-slate-400'
      }`}>
        {count}
      </span>
    )}
  </button>
);
