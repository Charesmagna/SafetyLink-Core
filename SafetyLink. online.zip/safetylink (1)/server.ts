import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
const JWT_SECRET = process.env.JWT_SECRET || 'safetylink-super-secret-key-2026';

// Initialize SQLite Database
const db = new Database('safetylink.db');

// Setup Database Schema
db.exec(`
  CREATE TABLE IF NOT EXISTS organizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    org_code TEXT NOT NULL UNIQUE,
    org_name TEXT NOT NULL,
    admin_password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    org_id INTEGER NOT NULL REFERENCES organizations(id),
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    latitude REAL,
    longitude REAL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(org_id, phone)
  );

  CREATE TABLE IF NOT EXISTS panic_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    latitude REAL,
    longitude REAL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    org_id INTEGER NOT NULL REFERENCES organizations(id),
    type TEXT NOT NULL,
    user_name TEXT,
    description TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// Seed Demo Org
const seedDemo = () => {
  const org = db.prepare('SELECT * FROM organizations WHERE org_code = ?').get('SAFELINK-DEMO');
  if (!org) {
    const hash = bcrypt.hashSync('demo1234', 10);
    db.prepare('INSERT INTO organizations (org_code, org_name, admin_password_hash) VALUES (?, ?, ?)').run('SAFELINK-DEMO', 'SafetyLink Demo', hash);
  }
};
seedDemo();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Log all API requests
  app.use('/api', (req, res, next) => {
    console.log(`[API] ${req.method} ${req.path}`);
    next();
  });

  // API ROUTES

  // Auth Middleware for Org Admin
  const requireAuth = (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    const token = authHeader.split(' ')[1];
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      req.orgId = decoded.orgId;
      req.orgCode = decoded.orgCode;
      next();
    } catch (err) {
      res.status(401).json({ error: 'Invalid token' });
    }
  };

  // POST /api/login (Admin)
  app.post('/api/login', (req, res) => {
    const { org_code, admin_password } = req.body;
    const org: any = db.prepare('SELECT * FROM organizations WHERE org_code = ?').get(org_code);
    
    if (!org || !bcrypt.compareSync(admin_password, org.admin_password_hash)) {
      return res.status(401).json({ error: 'Invalid organization code or password' });
    }

    const token = jwt.sign({ orgId: org.id, orgCode: org.org_code }, JWT_SECRET, { expiresIn: '24h' });
    
    db.prepare('INSERT INTO events (org_id, type, description) VALUES (?, ?, ?)').run(org.id, 'login', 'Admin logged in');
    
    res.json({ token, org_name: org.org_name, org_code: org.org_code });
  });

  // POST /api/register (APK)
  app.post('/api/register', (req, res) => {
    const { org_code, name, phone, password } = req.body;
    const org: any = db.prepare('SELECT id FROM organizations WHERE org_code = ?').get(org_code);
    
    if (!org) {
      return res.status(404).json({ error: 'Organization not found' });
    }

    try {
      const hash = bcrypt.hashSync(password, 10);
      db.prepare('INSERT INTO users (org_id, name, phone, password_hash) VALUES (?, ?, ?, ?)').run(org.id, name, phone, hash);
      db.prepare('INSERT INTO events (org_id, type, user_name, description) VALUES (?, ?, ?, ?)').run(org.id, 'register', name, 'User registered via APK');
      res.json({ success: true });
    } catch (err: any) {
      if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
        res.status(400).json({ error: 'Phone number already registered for this organization' });
      } else {
        res.status(500).json({ error: 'Registration failed' });
      }
    }
  });

  // GET /api/users
  app.get('/api/users', requireAuth, (req: any, res: any) => {
    const users = db.prepare('SELECT id, name, phone, latitude, longitude, created_at FROM users WHERE org_id = ?').all(req.orgId);
    
    // Attach panic status
    const result = users.map((u: any) => {
      const panic = db.prepare('SELECT status FROM panic_alerts WHERE user_id = ? AND status = ? ORDER BY created_at DESC LIMIT 1').get(u.id, 'active');
      return { ...u, panic_status: (panic as any)?.status || 'inactive' };
    });

    res.json({ users: result });
  });

  // POST /api/location (APK)
  app.post('/api/location', (req, res) => {
    const { org_code, phone, latitude, longitude } = req.body;
    const org: any = db.prepare('SELECT id FROM organizations WHERE org_code = ?').get(org_code);
    if (!org) return res.status(404).json({ error: 'Org not found' });

    const user: any = db.prepare('SELECT id, name FROM users WHERE org_id = ? AND phone = ?').get(org.id, phone);
    if (!user) return res.status(404).json({ error: 'User not found' });

    db.prepare('UPDATE users SET latitude = ?, longitude = ? WHERE id = ?').run(latitude, longitude, user.id);
    db.prepare('INSERT INTO events (org_id, type, user_name, description) VALUES (?, ?, ?, ?)').run(org.id, 'location', user.name, 'Location updated');
    
    res.json({ success: true });
  });

  // POST /api/panic (APK)
  app.post('/api/panic', (req, res) => {
    const { org_code, phone, latitude, longitude } = req.body;
    const org: any = db.prepare('SELECT id FROM organizations WHERE org_code = ?').get(org_code);
    if (!org) return res.status(404).json({ error: 'Org not found' });

    const user: any = db.prepare('SELECT id, name FROM users WHERE org_id = ? AND phone = ?').get(org.id, phone);
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (latitude && longitude) {
      db.prepare('UPDATE users SET latitude = ?, longitude = ? WHERE id = ?').run(latitude, longitude, user.id);
    }

    db.prepare('INSERT INTO panic_alerts (user_id, latitude, longitude) VALUES (?, ?, ?)').run(user.id, latitude, longitude);
    db.prepare('INSERT INTO events (org_id, type, user_name, description) VALUES (?, ?, ?, ?)').run(org.id, 'panic', user.name, '🚨 PANIC ALERT TRIGGERED');
    
    res.json({ success: true });
  });

  // GET /api/panic
  app.get('/api/panic', requireAuth, (req: any, res: any) => {
    const panics = db.prepare(`
      SELECT p.id, p.latitude, p.longitude, p.status, p.created_at, u.name as user_name, u.phone as user_phone
      FROM panic_alerts p
      JOIN users u ON p.user_id = u.id
      WHERE u.org_id = ? AND p.status = 'active'
    `).all(req.orgId);
    res.json({ panics });
  });

  // POST /api/panic/resolve
  app.post('/api/panic/resolve', requireAuth, (req: any, res: any) => {
    const { panic_id } = req.body;
    const panic: any = db.prepare('SELECT user_id FROM panic_alerts WHERE id = ?').get(panic_id);
    
    if (panic) {
      db.prepare('UPDATE panic_alerts SET status = ? WHERE id = ?').run('resolved', panic_id);
      const user: any = db.prepare('SELECT name FROM users WHERE id = ?').get(panic.user_id);
      db.prepare('INSERT INTO events (org_id, type, user_name, description) VALUES (?, ?, ?, ?)').run(req.orgId, 'resolve', user?.name || 'Unknown', 'Panic alert resolved');
    }
    res.json({ success: true });
  });

  // GET /api/events
  app.get('/api/events', requireAuth, (req: any, res: any) => {
    const events = db.prepare('SELECT * FROM events WHERE org_id = ? ORDER BY created_at DESC LIMIT 100').all(req.orgId);
    res.json({ events });
  });

  // --- Incident Management ---
  app.post('/api/incidents', (req, res) => {
    const { type, status, location, assigned_to } = req.body;
    // Save incident to DB (pseudo-code)
    const incident = { id: Date.now(), type, status, location, assigned_to };
    console.log("New Incident:", incident);
    res.json({ success: true, incident });
  });

  app.get('/api/incidents', (req, res) => {
    // Fetch incidents from DB
    res.json([{ id: 1, type: 'panic_alert', status: 'resolved' }]);
  });

  // --- Field Operations ---
  app.post('/api/reports', (req, res) => {
    const { guard_id, report_type, notes, photo_url } = req.body;
    const report = { id: Date.now(), guard_id, report_type, notes, photo_url };
    console.log("New Report:", report);
    res.json({ success: true, report });
  });

  // --- IoT/Webhook Integrations ---
  app.post('/webhook/iot', (req, res) => {
    const { sensor_id, event_type, timestamp } = req.body;
    console.log(`IoT Alert from ${sensor_id}: ${event_type} at ${timestamp}`);
    // Trigger incident workflow
    res.sendStatus(200);
  });

  // --- Alerting & Notifications ---
  function send_push(user: any, alert_id: any) { console.log(`Push sent to ${user}`); }
  function send_sms(user: any, alert_id: any) { console.log(`SMS sent to ${user}`); }
  function call_voice(user: any, alert_id: any) { console.log(`Voice call to ${user}`); }
  function acknowledged(alert_id: any, user: any) { return false; } // placeholder

  app.post('/api/alerts/escalate', (req, res) => {
    const { alert_id, recipients } = req.body;
    (recipients || []).forEach((user: any) => {
      send_push(user, alert_id);
      if (!acknowledged(alert_id, user)) {
        send_sms(user, alert_id);
        if (!acknowledged(alert_id, user)) {
          call_voice(user, alert_id);
        }
      }
    });
    res.json({ success: true });
  });

  // --- Analytics ---
  app.get('/api/analytics/heatmap', (req, res) => {
    // Example: return last 30 days of incidents
    const data = [
      { lat: -29.85, lng: 31.02, type: 'panic_alert' },
      { lat: -29.86, lng: 31.03, type: 'suspicious_activity' }
    ];
    res.json(data);
  });

  // --- Modern Enhancements (AI Video Analytics placeholder) ---
  app.post('/api/ai/video', (req, res) => {
    const { frame_data } = req.body;
    // Run AI detection (pseudo-code)
    const suspicious = Math.random() > 0.5;
    if (suspicious) {
      console.log("Suspicious activity detected!");
    }
    res.json({ suspicious });
  });

  // GET /api/health
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:\${PORT}`);
  });
}

startServer();
