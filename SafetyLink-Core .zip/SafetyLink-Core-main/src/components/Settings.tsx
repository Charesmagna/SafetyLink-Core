import React, { useState } from 'react';
import { useAppStore } from '../utils/store';
import { motion, AnimatePresence } from 'motion/react';
import { translate, SA_LANGUAGES } from '../utils/translations';
import { SafetyLinkLogo } from './SafetyLinkLogo';
import { LocalNotificationService } from '../services/LocalNotificationService';

export const Settings: React.FC = () => {
  const { 
    auditLogs, 
    clearAuditLogs, 
    language, 
    downloadedLanguages, 
    setLanguage, 
    downloadLanguage,
    isBackgroundServiceRunning,
    toggleBackgroundService,
    backgroundServiceTick,
    bleDevices,
    userLocation,
    isFloatingWidgetDeployed,
    setFloatingWidgetDeployed,
    floatingWidgetSize,
    setFloatingWidgetSize
  } = useAppStore();

  const [filter, setFilter] = useState<'ALL' | 'SYSTEM' | 'BLE' | 'GPS' | 'DISPATCH' | 'SECURITY'>('ALL');
  const [shortcutTriggerEnabled, setShortcutTriggerEnabled] = useState<boolean>(() => localStorage.getItem('sl_shortcut_enabled') === 'true');
  const [downloadingCode, setDownloadingCode] = useState<string | null>(null);

  const t = (key: string) => translate(language, key);

  const handleShortcutToggle = (enabled: boolean) => {
    setShortcutTriggerEnabled(enabled);
    localStorage.setItem('sl_shortcut_enabled', String(enabled));
    useAppStore.getState().addAuditLog(
      'SYSTEM',
      'INFO',
      `Homescreen Quick-Trigger ${enabled ? 'Enabled' : 'Disabled'}`,
      'Shortcut configured to bypass biometric locks and trigger emergency sequence on instant click.'
    );
  };

  const filteredLogs = auditLogs.filter(log => {
    if (filter === 'ALL') return true;
    return log.category === filter;
  });

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel rounded-3xl p-5 shadow-2xl w-full max-w-md mx-auto relative overflow-hidden scanlines"
    >
      <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-purple-500 via-pink-400 to-purple-500 neon-glow-blue" />
      <div className="absolute inset-0 digital-grid opacity-10 pointer-events-none" />

      <div className="border-b border-slate-900 pb-3.5 text-left relative z-10 flex items-center gap-2">
        <SafetyLinkLogo size={18} glowColor="rgba(168, 85, 247, 0.4)" />
        <div>
          <h3 className="text-xs font-black text-slate-100 tracking-[0.2em] font-display uppercase">
            {t('settings.title')}
          </h3>
          <p className="text-[10px] font-mono text-slate-500 mt-0.5">
            {t('settings.subtitle')}
          </p>
        </div>
      </div>

      {/* Diagnostics Quick Panel */}
      <div className="space-y-3 text-left mt-4 relative z-10 font-mono">
        <h4 className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-display">
          {t('settings.diagnostics_title')}
        </h4>
        <div className="grid grid-cols-2 gap-3 text-[10px] font-bold">
          <button
            onClick={() => {
              useAppStore.getState().addAuditLog('SYSTEM', 'INFO', 'Self-Test Initiated', 'Checking GATT profiles, GPS providers, and local caches.');
              useAppStore.getState().addToast("All system diagnostics are functional. BLE: Stable, GPS: High accuracy locked.", "success");
            }}
            className="bg-slate-950/40 border border-slate-900 rounded-2xl p-3 text-slate-200 hover:bg-slate-900 hover:text-white transition-all text-center"
          >
            {t('settings.diagnose_btn')}
          </button>
          <button
            onClick={clearAuditLogs}
            className="bg-slate-950/40 border border-red-500/10 rounded-2xl p-3 text-red-400 hover:bg-red-950/20 transition-all text-center"
          >
            {t('settings.purge_btn')}
          </button>
        </div>
      </div>

      {/* Background Service & Device System Tray Notification Panel */}
      <div className="space-y-3.5 text-left border-t border-slate-900 pt-4 mt-4 relative z-10 font-mono">
        <h4 className="text-[9px] font-bold text-slate-500 font-display uppercase tracking-widest">
          🛡️ SYSTEM TRAY & ACTIVE CONNECTION
        </h4>
        <div className="bg-slate-950/30 border border-slate-900 rounded-2xl p-4 space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1 text-left flex-1">
              <span className="text-[11px] font-extrabold text-slate-200 block font-display uppercase tracking-wide">
                Phone Notification Bar Status
              </span>
              <span className="text-[9px] text-slate-500 block leading-normal font-sans">
                Pushes a persistent, real-time status card to your phone's native notification tray. This ensures constant background link with your wearable panic button and prevents Android from killing the sensor listener.
              </span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-0.5">
              <input
                type="checkbox"
                checked={isBackgroundServiceRunning}
                onChange={() => {
                  toggleBackgroundService();
                  useAppStore.getState().addAuditLog(
                    'SYSTEM',
                    isBackgroundServiceRunning ? 'WARN' : 'INFO',
                    isBackgroundServiceRunning ? 'Background Service Stopped' : 'Background Service Started',
                    'State toggled via settings controller. System tray status card synchronized.'
                  );
                }}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-900 border border-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-500 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600 peer-checked:after:bg-white"></div>
            </label>
          </div>

          {/* Quick System Tray Diagnostics */}
          <div className="bg-slate-950/80 border border-slate-900 rounded-xl p-3 text-[8.5px] text-slate-400 space-y-2">
            <div className="flex justify-between items-center">
              <span>SYSTEM NOTIFICATION STATE:</span>
              {isBackgroundServiceRunning ? (
                <span className="text-emerald-400 font-black animate-pulse flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  PERSISTENT IN PHONE TRAY
                </span>
              ) : (
                <span className="text-red-400 font-black flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  SUSPENDED / OFFLINE
                </span>
              )}
            </div>

            {isBackgroundServiceRunning && (
              <>
                <div className="flex justify-between">
                  <span>ACTIVE BACKGROUND TICK:</span>
                  <span className="text-slate-300 font-bold">#{backgroundServiceTick}</span>
                </div>
                <div className="flex justify-between">
                  <span>GPS COORDINATES:</span>
                  <span className="text-blue-400 font-bold">
                    {userLocation ? `${userLocation.lat.toFixed(5)}, ${userLocation.lng.toFixed(5)}` : 'ACQUIRING...'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>HARDWARE LINK:</span>
                  <span className="text-slate-300 font-bold">
                    {bleDevices.length > 0 
                      ? `${bleDevices.filter(d => d.connectionState === 'CONNECTED').length} connected BLE`
                      : 'No iTAG paired'}
                  </span>
                </div>
              </>
            )}
          </div>

          {/* Request Phone Notification Permission Button */}
          <button
            type="button"
            onClick={async () => {
              const granted = await LocalNotificationService.requestPermission();
              if (granted) {
                useAppStore.getState().addToast("Native phone notification bar permission granted!", "success");
                useAppStore.getState().addAuditLog('SYSTEM', 'INFO', 'Notification Permission Granted', 'Operator approved native device notification permissions.');
              } else {
                useAppStore.getState().addToast("Native notification permission was denied or not supported.", "warn");
              }
            }}
            className="w-full py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[9px] font-bold rounded-xl text-slate-300 hover:text-white transition-all text-center uppercase tracking-wider"
          >
            🔒 Re-verify Phone Notification Permission
          </button>
        </div>
      </div>

      {/* Language & Localization Panel */}
      <div className="space-y-3 text-left border-t border-slate-900 pt-4 mt-4 relative z-10">
        <h4 className="text-[9px] font-bold text-slate-500 font-display uppercase tracking-widest">
          {t('settings.language_title')}
        </h4>
        <div className="bg-slate-950/30 border border-slate-900 rounded-2xl p-4 space-y-4">
          <div className="space-y-1">
            <span className="text-[11px] font-extrabold text-slate-200 block font-display uppercase tracking-wide">
              {t('settings.language_subtitle')}
            </span>
            <span className="text-[9.5px] text-slate-500 block leading-normal">
              Toggle the primary application language instantly, or download additional official South African languages.
            </span>
          </div>

          {/* Installed Languages Toggle */}
          <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
            {SA_LANGUAGES.filter(lang => lang.status === 'preloaded' || downloadedLanguages.includes(lang.code)).map(lang => (
              <button
                key={lang.code}
                onClick={() => setLanguage(lang.code)}
                className={`py-2 px-2.5 rounded-xl border flex items-center justify-between transition-all ${
                  language === lang.code
                    ? 'bg-emerald-600/20 border-emerald-500/40 text-emerald-400 font-bold shadow-md shadow-emerald-950/20'
                    : 'bg-slate-950 border-slate-900 text-slate-400 hover:bg-slate-900 hover:text-slate-300'
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <span>{lang.flag}</span>
                  <span>{lang.nativeName}</span>
                </span>
                {language === lang.code && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                )}
              </button>
            ))}
          </div>

          {/* Download other SA languages */}
          <div className="space-y-2 border-t border-slate-900/60 pt-3">
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider font-display block">
              {t('settings.download_language')}
            </span>
            <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
              {SA_LANGUAGES.filter(lang => lang.status !== 'preloaded' && !downloadedLanguages.includes(lang.code)).map(lang => {
                const isThisDownloading = downloadingCode === lang.code;
                return (
                  <div key={lang.code} className="flex justify-between items-center p-2 bg-slate-950/60 border border-slate-900 rounded-xl font-mono text-[9px] gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm shrink-0">{lang.flag}</span>
                      <div className="text-left">
                        <p className="font-bold text-slate-200 leading-tight">{lang.name} ({lang.nativeName})</p>
                        <p className="text-[7.5px] text-slate-500 font-mono uppercase tracking-tight">{lang.code.toUpperCase()} · SA LANGUAGE PACK</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={isThisDownloading}
                      onClick={async () => {
                        setDownloadingCode(lang.code);
                        await downloadLanguage(lang.code);
                        setDownloadingCode(null);
                        useAppStore.getState().addToast(`${lang.name} language package successfully downloaded and registered!`, "success");
                      }}
                      className="px-2 py-1.5 text-[8.5px] font-bold rounded-lg bg-blue-600/20 hover:bg-blue-600/40 text-blue-400 hover:text-white border border-blue-500/25 transition-all flex items-center gap-1 shrink-0"
                    >
                      {isThisDownloading ? (
                        <>
                          <span className="w-1 h-1 rounded-full bg-blue-400 animate-ping shrink-0" />
                          <span>{t('settings.downloading')}</span>
                        </>
                      ) : (
                        <span>{t('settings.download_btn')}</span>
                      )}
                    </button>
                  </div>
                );
              })}
              {SA_LANGUAGES.filter(lang => lang.status !== 'preloaded' && !downloadedLanguages.includes(lang.code)).length === 0 && (
                <p className="text-center text-slate-600 italic text-[9px] py-2">All South African languages are fully downloaded.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Homescreen Red Circle Shortcut Trigger Settings */}
      <div className="space-y-3.5 text-left border-t border-slate-900 pt-4 mt-4 relative z-10">
        <h4 className="text-[9px] font-bold text-slate-500 font-display uppercase tracking-widest">
          {t('settings.shortcut_title')}
        </h4>
        <div className="bg-slate-950/30 border border-slate-900 rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5 text-left pr-4">
              <span className="text-[11px] font-extrabold text-slate-200 block font-display uppercase tracking-wide">
                {t('settings.shortcut_name')}
              </span>
              <span className="text-[9px] text-slate-500 block leading-normal font-sans">
                {t('settings.shortcut_desc')}
              </span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={shortcutTriggerEnabled}
                onChange={(e) => handleShortcutToggle(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-900 border border-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-500 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-red-600 peer-checked:after:bg-white"></div>
            </label>
          </div>

          <AnimatePresence>
            {shortcutTriggerEnabled && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="pt-3.5 border-t border-slate-900/60 flex flex-col items-center gap-3"
              >
                <div className="text-[9px] text-slate-400 font-mono text-center uppercase tracking-wider">
                  Test Direct Launcher Widget:
                </div>
                
                {/* Pulsing Red Circle Interactive Widget */}
                <button
                  onClick={() => {
                    useAppStore.getState().triggerPanic("DISTRESS: Instant trigger activated from homescreen red circle quick-shortcut.");
                  }}
                  className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-b from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 hover:scale-105 active:scale-95 transition-all duration-300 shadow-xl shadow-red-950 border border-red-500/20"
                >
                  <span className="absolute inset-0 rounded-full bg-red-500/20 animate-ping opacity-75 pointer-events-none" />
                  <span className="absolute inset-1 rounded-full border-2 border-dashed border-red-300/20 group-hover:rotate-45 transition-transform duration-1000" />
                  <span className="text-[10px] font-black text-white tracking-widest font-mono">SOS</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    useAppStore.getState().addToast("Pinning Red Circle Shortcut Trigger to your Android Home Screen... Success! (Via ShortcutManager API)", "success");
                    useAppStore.getState().addAuditLog('SYSTEM', 'INFO', 'Homescreen Shortcut Pinned', 'Red circle launcher widget requested and pinned successfully.');
                  }}
                  className="text-[9px] py-2 px-4 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white font-mono font-bold rounded-xl transition-all w-full text-center"
                >
                  PIN TO NATIVE HOMESCREEN
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Sizable Movable Deployed Floating Widget Toggle */}
          <div className="pt-3.5 border-t border-slate-900/60 space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5 text-left pr-4">
                <span className="text-[11px] font-extrabold text-slate-200 block font-display uppercase tracking-wide">
                  Movable Floating SOS Button
                </span>
                <span className="text-[9px] text-slate-500 block leading-normal font-sans">
                  Deploy a sizing-adjustable, movable "breathing" SOS overlay. Works on top of standard interfaces. Double-tap the overlay to resize!
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={isFloatingWidgetDeployed}
                  onChange={(e) => {
                    setFloatingWidgetDeployed(e.target.checked);
                    useAppStore.getState().addAuditLog(
                      'SYSTEM',
                      'INFO',
                      `Movable Floating Widget ${e.target.checked ? 'Deployed' : 'Undeployed'}`,
                      'Floating tactical SOS shortcut layer synchronized on device screen.'
                    );
                    useAppStore.getState().addToast(
                      `Floating SOS Shortcut ${e.target.checked ? 'deployed on-screen' : 'removed'}!`,
                      e.target.checked ? 'success' : 'info'
                    );
                  }}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-900 border border-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-500 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600 peer-checked:after:bg-white"></div>
              </label>
            </div>

            {isFloatingWidgetDeployed && (
              <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-900 space-y-2.5 font-mono text-[9px]">
                <div className="flex justify-between items-center text-slate-400">
                  <span>WIDGET SIZE PRESET:</span>
                  <span className="text-emerald-400 font-bold">{floatingWidgetSize}px</span>
                </div>
                <input
                  type="range"
                  min="48"
                  max="140"
                  value={floatingWidgetSize}
                  onChange={(e) => setFloatingWidgetSize(Number(e.target.value))}
                  className="w-full accent-emerald-400 bg-slate-800 h-1 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Interactive Audit Logs Ledger */}
      <div className="space-y-3 text-left border-t border-slate-900 pt-4 mt-4 relative z-10">
        <div className="flex justify-between items-center">
          <h4 className="text-[9px] font-bold text-slate-500 font-display uppercase tracking-widest">
            {t('settings.ledger_title')}
          </h4>
          <span className="text-[9px] font-mono font-bold text-slate-400 bg-slate-950 px-2 py-0.5 rounded-full border border-slate-900">
            {filteredLogs.length} {t('settings.events_badge')}
          </span>
        </div>

        {/* Filter Badges */}
        <div className="flex flex-wrap gap-1.5 font-mono text-[8px] font-bold">
          {(['ALL', 'SYSTEM', 'BLE', 'GPS', 'DISPATCH', 'SECURITY'] as const).map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-2.5 py-1 rounded-full border transition-all ${
                filter === cat
                  ? 'bg-blue-600 border-blue-500/20 text-white shadow-md'
                  : 'bg-slate-950 border-slate-900 text-slate-500 hover:text-slate-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Audit Log Box */}
        <div className="h-44 bg-slate-950/40 border border-slate-900 rounded-2xl overflow-y-auto p-3.5 font-mono text-[10px] space-y-3.5 scrollbar-none">
          {filteredLogs.length === 0 ? (
            <p className="text-slate-600 text-center py-10 italic">Ledger buffer empty.</p>
          ) : (
            filteredLogs.map(log => {
              const dateStr = new Date(log.timestamp).toLocaleTimeString();
              const isSevere = log.severity === 'SEVERE';
              const isWarn = log.severity === 'WARN';

              return (
                <div key={log.id} className="border-b border-slate-900/40 pb-2.5 last:border-0 last:pb-0 text-left">
                  <div className="flex justify-between items-center gap-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className={`w-1 h-1 rounded-full ${isSevere ? 'bg-red-500 animate-ping' : isWarn ? 'bg-orange-500' : 'bg-slate-500'}`} />
                      <span className="text-slate-500 text-[8px]">{dateStr}</span>
                      <span className="text-slate-400 font-bold text-[8px] tracking-wider uppercase bg-slate-900 px-1.5 py-0.5 rounded border border-slate-900">
                        {log.category}
                      </span>
                    </div>
                    <span className={`font-black text-[8px] tracking-wider px-1.5 py-0.5 rounded-full ${isSevere ? 'bg-red-950/20 border-red-500/20 text-red-400' : isWarn ? 'bg-orange-950/20 border-orange-500/20 text-orange-400' : 'bg-slate-900 text-slate-500'}`}>
                      {log.severity}
                    </span>
                  </div>
                  <p className="text-slate-200 font-bold mt-1 leading-normal">{log.message}</p>
                  {log.details && (
                    <p className="text-slate-500 text-[9px] mt-1 leading-normal bg-slate-950/40 p-1.5 rounded-lg border border-slate-900/30">
                      {log.details}
                    </p>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </motion.div>
  );
};
